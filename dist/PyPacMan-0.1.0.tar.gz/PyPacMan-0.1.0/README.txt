========
PyPacMan
========


Neste repositório, está presente uma pequena versão em Python do clássico game PacMan. 

O Sistema é dividido em três partes:

1. AI - este módulo é responsável pelo controle dos fantasmas. 
2. IO - este módulo é responsável pela captura das ações do/s jogador/es.
3. Game - este módulo é responsável pelo controle do jogo.
4. GUI - este módulo é responsável pelo controle da interface gráfica do usuário e pela integração dos diversos elementos do sistema



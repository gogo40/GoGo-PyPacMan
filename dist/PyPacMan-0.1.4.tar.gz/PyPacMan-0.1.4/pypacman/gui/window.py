import sys, pygame

class Window:
	def __init__(self):
		pygame.init()
		self.delay  = 100
		#dimensao da celula
		self.dim_cell = 15

		#velocidade da celula
		self.speed = self.dim_cell

		#dimensao da tela
		self.size = self.width, self.height = 80 * self.dim_cell, 40 * self.dim_cell
		self.screen = pygame.display.set_mode(self.size)

		#cor do fundo
		self.color = 0, 0, 0


		#elementos do jogo
		self.pacmano = pygame.image.load("imgs/pacman.png")
		self.pacman = pacmano = pygame.transform.smoothscale(pacmano, (dim_cell, dim_cell))

		self.fruta = pygame.image.load("imgs/fruta.png")
		self.fantasma = [
			pygame.image.load("imgs/fantasma1.png"),
			pygame.image.load("imgs/fantasma2.png"),
			pygame.image.load("imgs/fantasma3.png"),
			pygame.image.load("imgs/fantasma4.png")
		]
		self.parede = pygame.image.load("imgs/parede.png")

		self.position = pacmano.get_rect()
		self.d = [0, 0]

	def run(self):
		while 1:
			for event in pygame.event.get():
				if event.type == pygame.QUIT: sys.exit()
				if event.type == pygame.KEYDOWN:
					if event.key == pygame.K_LEFT:
						self.d[0] = -self.speed
						self.d[1] = 0
						self.pacman = pygame.transform.rotate(self.pacmano, 360)
					elif event.key == pygame.K_RIGHT:
						self.d[0] = self.speed
						self.d[1] = 0
						self.pacman = pygame.transform.rotate(self.pacmano, 180)
					elif event.key == pygame.K_UP:
						self.d[0] = 0
						self.d[1] = -self.speed
						self.pacman = pygame.transform.rotate(self.pacmano, 270)
					elif event.key == pygame.K_DOWN:
						self.d[0] = 0
						self.d[1] = self.speed
						self.pacman = pygame.transform.rotate(self.pacmano, 90)
				if event.type == pygame.KEYUP:
					self.d = [0, 0]
		
			if (self.position[0] + self.d[0] >= 0 and 
				self.position[0] + self.d[0] <= self.width - self.position[2] and
				self.position[1] + self.d[1] >= 0 and 
				self.position[1] + self.d[1] <= self.height - self.position[3]):
				self.position = self.position.move(d)		
				self.screen.fill(self.color)
				self.screen.blit(self.pacman, self.position)
				pygame.display.flip()
			pygame.time.delay(self.delay)




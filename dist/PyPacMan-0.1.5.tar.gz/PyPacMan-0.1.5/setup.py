from distutils.core import setup

setup(
    name='PyPacMan',
    version='0.1.5',
    author='Pericles Lopes Machado',
    author_email='pericles.raskolnikoff@gmail.com',
    packages=['pypacman','pypacman.ai','pypacman.gui'],
    scripts=[
	'pypacman/ai/a_star.py',
	'pypacman/ai/ai_control.py',
	'pypacman/gui/window.py'
],
    url='http://pypi.python.org/pypi/PyPacMan/',
    license='LICENSE.txt',
    description='Useful towel-related stuff.',
    long_description=open('README.txt').read(),
    install_requires=[
	"pygame >= 1.0.0"
    ],
	package_data = {
        '': ['*.txt'],
		'': ['*.png']
    }

)
